'''

/engine = runtime trading loop

✔ live trading
✔ strategy orchestration
✔ position/risk management
✔ websocket processing
✔ order routing

'''